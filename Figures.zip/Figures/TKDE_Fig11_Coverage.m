%% Date: 2018-3-19

clc; clear;close all;
str1={'Protein194'; 'DD';'VOC'; 'Cifar100';  'SUN'; 'ilsvrc65'};
m = length(str1);

for i =1:m
filename=['/code/Figures/Obj ' str1{i}];
load (filename);
    fontsize = 20;
    figure1 = figure('Color',[1 1 1]);
    axes1 = axes('Parent',figure1,'FontSize',fontsize,'FontName','Times New Roman');
    
    plot(obj,'LineWidth',4,'Color',[0.356862753629684 0.607843160629272 0.835294127464294]);
    xlim(axes1,[0.8 10]);
    set(gca,'FontName','Times New Roman','FontSize',fontsize);
    xlabel('Iteration number');
    ylabel('Objective function value');
colormap jet
print(['/results/Coverage' str1{i}], '-dpdf');
end

 