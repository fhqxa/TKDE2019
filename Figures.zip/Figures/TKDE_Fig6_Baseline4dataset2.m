
fontsize = 18;

str1={'VOC'; 'Cifar100';'SUN';'ilsvrc65'};
m = length(str1);
figure1 = figure('Color',[1 1 1]);
filename=['/code/Figures/ZH2HIFSRRSVM ' str1{1}]; 
load(filename);
baseline1=FHMean(:,1:end-1);
filename=['HIFSRRSVM ' str1{1}];
load(filename);
baseline2=FHMean(:,2:end);
baseline=[baseline1,[0;0],baseline2];
maxBase = max(baseline(2,:));
stem(baseline(2,:),'--','LineWidth',1.5);
line([0,10.5],[maxBase,maxBase],'LineWidth',1);
  axis([0.4,10.5,maxBase-0.5,maxBase+0.15]);
 %legend('HiRR-FS ','Baseline',fontsize);
ylabel('Hierarchical \it F\rm_1-measure','FontSize',fontsize);
xlabel('Number of selected features');
annotation(figure1,'textbox',...
    [0.424214285714283 0.426190476190477 0.0615000000000002 0.0404761904761912],...
    'Color',[0 0.447058823529412 0.741176470588235],...
    'String',{'......'},...
    'FontSize',28,...
    'FontName','Times New Roman',...
    'FitBoxToText','off',...
    'EdgeColor',[1 1 1]);
Xtick_pos=1:10;
Xtick_label={'40','80','120','160','\cdot\cdot\cdot\cdot\cdot\cdot','20%','30%','40%','50%','All'}; 
set(gca,'XTickLabel',Xtick_label, 'XTick',Xtick_pos,'FontSize',fontsize,'FontName','times');
print('/results/baselineVOC', '-dpdf')
for i =2:m
    figure1 = figure('Color',[1 1 1]);
filename=['/code/Figures/ZH2HIFSRRSVM ' str1{i}]; 
load(filename);
baseline1=FHMean(:,1:4);
filename=['HIFSRRSVM ' str1{i}];
load(filename);
baseline2=FHMean(:,2:end);
baseline=[baseline1,[0;0],baseline2];
maxBase = max(baseline(2,:));
stem(baseline(2,:),'--','LineWidth',1.5);
line([0,10.5],[maxBase,maxBase],'LineWidth',1);
axis([0.4,10.5,maxBase-0.5,maxBase+0.15]);
%legend('HiRR-FS ','Baseline',fontsize);
ylabel('Hierarchical \it F\rm_1-measure','FontSize',fontsize);
xlabel('Number of selected features');
annotation(figure1,'textbox',...
    [0.424214285714283 0.426190476190477 0.0615000000000002 0.0404761904761912],...
    'Color',[0 0.447058823529412 0.741176470588235],...
    'String',{'......'},...
    'FontSize',28,...
    'FontName','Times New Roman',...
    'FitBoxToText','off',...
    'EdgeColor',[1 1 1]);
Xtick_pos=1:10;
Xtick_label={'40','80','120','160','\cdot\cdot\cdot\cdot\cdot\cdot','20%','30%','40%','50%','All'}; 
set(gca,'XTickLabel',Xtick_label, 'XTick',Xtick_pos,'FontSize',fontsize,'FontName','times');
print(['/results/baseline' str1{i}], '-dpdf')
end