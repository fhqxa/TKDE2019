clear;clc;close all;
fontsize=24;
%HIFSRR	HIFSRRpar	HIFSRRsib	HIFSRRfam	

F194=[	0.708920188	0.711032864	0.710328638	0.711737089];
DD=[ 	0.858424408	0.858424408	0.85787796	0.860619308];

Cifar100=[	0.6955	0.6957	0.695933333	0.695533333	];
ilsvrc65=[	0.900822607	0.902026118	0.901033702	0.902427229];
SUN=[	0.784824744	0.78482468	0.784625252	0.785279054	];
VOC=[	0.659975515	0.660547457	0.660314878	0.660387016	];



for ID =1:6
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure1 = figure('Color',[1 1 1]);
axes1 = axes('Parent',figure1);
switch ID
    case 1
        dataset=F194;   
    case 2
        dataset=DD;
    case 3
        dataset=VOC;
    case 4
        dataset=Cifar100;
    case 5
        dataset =SUN;
    case 6
        dataset= ilsvrc65;        
end

% dataset(:,end)=mean(dataset(:,1:4),2);
% dataset=dataset(:,4);
d(:,ID)=dataset;
m=4;
bar(dataset','BarWidth',0.5,'FaceColor',[0.356862753629684 0.607843160629272 0.835294127464294],...
    'EdgeColor',[1 1 1]);
% if (ID==2)
%   axis([0.5,5.5,0.7, max(dataset(:))+0.1]);
% else
    axis([0.3,4.7,min(dataset(:))-0.0005, max(dataset(:))+0.0003]);
% end
set(gca,'FontName','Times New Roman','FontSize',fontsize);
Xtick_pos=1:1:m;

Xtick_label={'HiRR','Par','Sib','Fam'};   

        

ylabel('\fontname{times}Hierarchical \it F\rm_1-measure','FontSize',fontsize);
% xlabel('Number of selected features');
% legend('mRMR ','HiRRpar-FS','HiRRsib-FS',fontsize);
% legend('HiRR-FS','HiRRpar-FS','HiRRsib-FS','HiRRfam-FS',fontsize);
% legend('mRMR ',fontsize);
set(gca,'XTickLabel',Xtick_label, 'XTick',Xtick_pos,'FontSize',fontsize);
print(['../../results/Regularization' int2str(ID)], '-dpdf');
% bar(dataDD')
% axis([0.5,5.5,0.82,0.87]);
end